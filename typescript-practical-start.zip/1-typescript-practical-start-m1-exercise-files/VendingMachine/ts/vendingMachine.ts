class vendingMachine {
}