/// <reference path="vendingMachine.ts" />
let machine = new vendingMachine();