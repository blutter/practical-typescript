var vendingMachine = (function () {
    function vendingMachine() {
    }
    return vendingMachine;
}());
/// <reference path="vendingMachine.ts" />
var machine = new vendingMachine();
//# sourceMappingURL=app.js.map