class Quarter {
    private value = .25;
    get Value() {
        return this.value;
    }
    getImageUrl () {
        return "img/Quarter.png"
    };
}